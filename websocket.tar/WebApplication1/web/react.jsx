var App = Grommet.App;
var Button = Grommet.Button;
var Heading = Grommet.Heading;
var Paragraph = Grommet.Paragraph;
var Tab = Grommet.Tab;
var Tabs = Grommet.Tabs;

function Image(props) {
    return <img width={props.width} src={props.src}></img>;
}    
    
class Page extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            error: null,
            image: null,
            xml: null
        };
        
        this.getSVG = this.getSVG.bind(this);
        this.getXML = this.getXML.bind(this);
    }

    componentDidMount() {
        this.ws = new WebSocket('ws://localhost:8080/WebApplication1/websocket');
        this.ws.onmessage = e => {this.messageHandler(e)};
        this.ws.onerror = e => this.setState({error: 'WebSocket error'});
        this.ws.onclose = e => !e.wasClean && this.setState({error: `WebSocket error: ${e.code} ${e.reason}`});
    }

    messageHandler(message) {
        //console.log(message);
        var jsonMessage = JSON.parse(message.data);
        if (jsonMessage.type == "svg") {
            this.setState ({
                image: <Image width="10%" src={jsonMessage.content} />
            }, function() {
                image = this.state.image;
            });
        } else if (jsonMessage.type == "xml") {
            this.setState ({
                xml: <Button href={jsonMessage.content} label="Open XML"></Button>
            }, function() {
                console.log("ok");
                xml = this.state.xml;
            });
        }
    }

    componentWillUnmount() {
        this.ws.close();
    }
    
    getSVG() {
        // Request the SVG filename
        // The Java server sends a message back, which is handled in messageHandler
        this.ws.send("svg");
    }
    
    getXML() {
        // Request the XML filename
        // The Java server sends a message back, which is handled in messageHandler
        this.ws.send("xml");
    }
    
    render() {
        return (
            <App>
            <Heading align='center'>Hello CS314</Heading> 
            <Tabs>
                <Tab title="SVG">
                    <Button label="Click here for an SVG" onClick={this.getSVG}></Button>
                    <br />
                    <br />
                    <br />
                    {this.state.image}
                </Tab>
                <Tab title="XML">
                    <Button label="Click here for some XML" onClick={this.getXML}></Button>
                    <br />
                    <br />
                    <br />
                    {this.state.xml}
                </Tab>
            </Tabs>
            </App>
        );
    }
}

ReactDOM.render(<Page/>, document.getElementById('content'));
