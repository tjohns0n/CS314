
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.json.Json;
import javax.json.JsonObject;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;

import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/websocket")
public class WebsocketTest {

    private final static String WORKDIR = WebsocketTest.class.getProtectionDomain().getCodeSource().getLocation().getPath();
    private final static String FILEPATH = WORKDIR.substring(0, WORKDIR.indexOf("WEB-INF/"));

    private BufferedWriter bw;
    
    @OnMessage
    public void onMessage(String message, Session session) throws IOException,
            InterruptedException {
        if (message.equals("svg")) {
            String svg = requestSVG().toString();
            session.getBasicRemote().sendText(svg);
        } else if (message.equals("xml")) {
            String xml = requestXML().toString();
            System.out.println(xml);
            session.getBasicRemote().sendText(xml);
        }
    }

    private JsonObject requestSVG() throws IOException {
        JsonObject svg = Json.createObjectBuilder()
                .add("type", "svg")
                .add("content", writeSVG())
                .build();
        return svg;
    }
    
    private JsonObject requestXML() throws IOException {
        JsonObject xml = Json.createObjectBuilder()
                .add("type", "xml")
                .add("content", writeXML())
                .build();
        return xml;
    }

    private String writeSVG() throws IOException {
        bw = new BufferedWriter(new FileWriter(FILEPATH + "test.svg"));
        String svg = "";
        //data:image/svg+xml,
        svg += "<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400'>";
        svg += "<rect width=\"400\" height=\"400\" style=\"fill:rgb(0,0,255);"
                + "stroke-width:3;stroke:rgb(0,0,0)\" /></svg>";
        bw.write(svg);
        bw.close();
        return "test.svg";
    }
    
    private String writeXML() throws IOException {
        bw = new BufferedWriter(new FileWriter(FILEPATH + "test.xml"));
        String xml = "";
        xml += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<shoppingList>\n\t<listItem>Banana</listItem>\n\t<listItem>Bee repellent</listItem>\n</shoppingList>";
        bw.write(xml);
        bw.close();
        return "test.xml";
    }

    @OnOpen
    public void onOpen() throws IOException {
        System.out.println("Client connected");
    }

    @OnClose
    public void onClose() {
        System.out.println("Connection closed");
    }
}
